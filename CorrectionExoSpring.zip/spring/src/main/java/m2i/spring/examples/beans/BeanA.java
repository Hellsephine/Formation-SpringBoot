package m2i.spring.examples.beans;


public class BeanA {

	private String name;
	
	public BeanA(String name)
	{
		this.name = name;
	}
	
	public String getName()
	{
		return name;
	}
}
