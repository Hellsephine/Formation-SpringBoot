package m2i.spring.examples.buying.exception;


public class ForbiddenException extends Exception {

	private static final long serialVersionUID = 2251960347102103013L;

}
