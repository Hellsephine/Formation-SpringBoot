package m2i.spring.exercices.annotations.exo1;


@Exo1Annotation
public class AnnotatedClass {

}
