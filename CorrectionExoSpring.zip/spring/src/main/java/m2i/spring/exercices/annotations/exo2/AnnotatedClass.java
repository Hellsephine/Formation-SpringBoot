package m2i.spring.exercices.annotations.exo2;

public class AnnotatedClass {

	@Exo2Annotation
	public void AnnotatedMethod()
	{
		
	}
}
