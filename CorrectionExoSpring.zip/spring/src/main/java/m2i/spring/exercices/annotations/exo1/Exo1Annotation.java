package m2i.spring.exercices.annotations.exo1;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Exo1Annotation {	
	
}
