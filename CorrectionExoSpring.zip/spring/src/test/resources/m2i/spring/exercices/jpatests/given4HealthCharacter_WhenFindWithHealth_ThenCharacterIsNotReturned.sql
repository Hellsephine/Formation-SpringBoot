INSERT INTO game_character (name, health) -- GameCharacter
VALUES
(
	'Florin',
	1
);