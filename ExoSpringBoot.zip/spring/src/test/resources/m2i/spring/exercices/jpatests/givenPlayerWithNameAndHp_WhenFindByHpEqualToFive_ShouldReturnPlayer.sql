INSERT INTO game_character (name,pdv)
VALUES 
('Two',5);