INSERT INTO game_character (name,pdv)
VALUES 
('One',4);