INSERT INTO game_character (name,pdv)
VALUES 
('Three',6);