INSERT INTO game_character (name,pdv)
VALUES 
('One',6),
('Two',6),
('Three',6),
('Four',6),
('Five',6),
('Six',6),
('Seven',6),
('Eight',6),
('Nine',6),
('Ten',6);