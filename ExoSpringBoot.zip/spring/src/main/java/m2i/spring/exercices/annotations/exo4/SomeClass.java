package m2i.spring.exercices.annotations.exo4;

public class SomeClass {

	@MethodAnnotation
	public void SomeMethod(String s) {
		System.out.println(s);
	}
}
