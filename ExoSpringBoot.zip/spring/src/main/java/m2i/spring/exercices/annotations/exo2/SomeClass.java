package m2i.spring.exercices.annotations.exo2;

public class SomeClass {

	@Annotation
	public void annotatedMethod() {
		
	}
	
	public void notAnnotatedMethod() {
		
	}
}
